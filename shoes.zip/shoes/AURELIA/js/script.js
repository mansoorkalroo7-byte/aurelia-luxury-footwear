document.addEventListener('DOMContentLoaded', () => {
    // --- Reveal Animations ---
    const revealElements = document.querySelectorAll('[data-reveal]');
    
    const revealCallback = (entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('revealed');
                observer.unobserve(entry.target);
            }
        });
    };
    
    const revealOptions = {
        threshold: 0.1,
        rootMargin: "0px 0px -50px 0px"
    };
    
    const revealObserver = new IntersectionObserver(revealCallback, revealOptions);
    
    revealElements.forEach(el => {
        revealObserver.observe(el);
    });
    
    // --- Mobile Menu Toggle ---
    const menuToggle = document.getElementById('menuToggle');
    const mainNav = document.getElementById('mainNav');
    
    menuToggle.addEventListener('click', () => {
        mainNav.classList.toggle('active');
        const expanded = mainNav.classList.contains('active');
        menuToggle.setAttribute('aria-expanded', expanded);
    });
    
    // Close menu when clicking a link
    mainNav.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', () => {
            mainNav.classList.remove('active');
            menuToggle.setAttribute('aria-expanded', false);
        });
    });
    
    // --- Cart Functionality ---
    const cartToggleBtn = document.getElementById('cartToggleBtn');
    const cartDrawerOverlay = document.getElementById('cartDrawerOverlay');
    const cartDrawerCloseBtn = document.getElementById('cartDrawerCloseBtn');
    const cartBadgeCount = document.getElementById('cartBadgeCount');
    const cartDrawerCount = document.getElementById('cartDrawerCount');
    const emptyCartState = document.getElementById('emptyCartState');
    const cartItemsList = document.getElementById('cartItemsList');
    const cartSubtotal = document.getElementById('cartSubtotal');
    
    let cart = [];
    
    // Open Cart
    cartToggleBtn.addEventListener('click', () => {
        cartDrawerOverlay.classList.add('active');
    });
    
    // Close Cart
    const closeCart = () => {
        cartDrawerOverlay.classList.remove('active');
    };
    
    cartDrawerCloseBtn.addEventListener('click', closeCart);
    cartDrawerOverlay.addEventListener('click', (e) => {
        if (e.target === cartDrawerOverlay) closeCart();
    });
    
    // Add to Cart
    const addToCartBtns = document.querySelectorAll('.add-to-cart-btn');
    addToCartBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            const productCard = e.target.closest('.product-card');
            const id = productCard.dataset.id;
            const title = productCard.dataset.title;
            const price = parseFloat(productCard.dataset.price);
            const image = productCard.dataset.image;
            
            addItemToCart({ id, title, price, image });
            showToast(`${title} added to cart`);
        });
    });
    
    function addItemToCart(item) {
        const existingItem = cart.find(i => i.id === item.id);
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push({ ...item, quantity: 1 });
        }
        updateCartUI();
    }
    
    function removeItemFromCart(id) {
        cart = cart.filter(item => item.id !== id);
        updateCartUI();
    }
    
    function updateCartUI() {
        const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
        const totalPrice = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        
        cartBadgeCount.textContent = totalItems;
        cartDrawerCount.textContent = `${totalItems} Items`;
        cartSubtotal.textContent = `$${totalPrice.toFixed(2)}`;
        
        if (cart.length === 0) {
            emptyCartState.style.display = 'flex';
            cartItemsList.innerHTML = '';
        } else {
            emptyCartState.style.display = 'none';
            renderCartItems();
        }
    }
    
    function renderCartItems() {
        cartItemsList.innerHTML = cart.map(item => `
            <div class="cart-item">
                <img src="${item.image}" alt="${item.title}" />
                <div class="cart-item-details">
                    <h4>${item.title}</h4>
                    <div class="price">$${item.price.toFixed(2)}</div>
                    <div class="cart-item-actions">
                        <span>Qty: ${item.quantity}</span>
                        <button class="remove-btn" onclick="window.removeCartItem('${item.id}')">Remove</button>
                    </div>
                </div>
            </div>
        `).join('');
    }
    
    // Global function for inline onclick handler
    window.removeCartItem = function(id) {
        removeItemFromCart(id);
    };
    
    // --- Toast Notifications ---
    const toastContainer = document.getElementById('toastContainer');
    
    function showToast(message) {
        const toast = document.createElement('div');
        toast.className = 'toast';
        toast.innerHTML = `
            <svg viewBox="0 0 24 24" width="20" height="20" fill="none">
                <path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            <span>${message}</span>
        `;
        
        toastContainer.appendChild(toast);
        
        setTimeout(() => {
            toast.classList.add('hiding');
            toast.addEventListener('animationend', () => {
                toast.remove();
            });
        }, 3000);
    }
    
    // --- Newsletter Form ---
    const newsletterForm = document.getElementById('newsletterForm');
    const newsletterNote = document.getElementById('newsletterNote');
    
    if(newsletterForm) {
        newsletterForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const email = document.getElementById('newsletterEmail').value;
            if(email) {
                newsletterNote.textContent = 'Thank you for subscribing!';
                newsletterNote.style.color = 'var(--color-primary)';
                newsletterForm.reset();
            }
        });
    }
});
